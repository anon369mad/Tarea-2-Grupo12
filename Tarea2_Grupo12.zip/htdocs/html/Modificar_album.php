<?php
require("db_config.php");
session_start();
include '../include/navbar.php';

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){
        echo"<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>";
        $nombre_album=$_POST["nombre_cancion"];
        $sql_statement="SELECT * from (select id_album,email from artista_tiene_album inner join personas on id = id_artista) as artistaCancion inner join album on id_album = id WHERE email = $1 and id_album = $2";
        $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"],$nombre_album));


        $row = pg_fetch_row($result);
        $id=$row[0];
        $nombre = $row[3];
        $imagen = $row[4];
        $fecha = $row[5];
        echo("<h3>INGRESE LOS DATOS NUEVAMENTE EN EL FORMULARIO</h3>");
        echo("<p>NOMBRE: ".$nombre."</p>");
        echo("<p>IMAGEN: ".$imagen."</p>");
        echo("<p>FECHA: ".$fecha."</p>");
        
        echo("<form action='modificar_Album2.php' method='POST'>
        <div>
            <label for='nombre'>Nombre</label>

            <input  value=$id type='hidden'name='Id_cancion' placeholder='Ingresa tu nombre' id='Id_cancion'>

            <input required=''  type='text'name='nombre' placeholder='Ingresa tu nombre' id='nombre'>
        </div>
    
        <div>
            <label for='imagen'>imagen</label>
            <input required='' type='text' name='imagen' placeholder='Ingresa la imagen' id='imagen'>
        </div>
    
        <div>
            <label for='Fecha'>Fecha composicion</label>
            <input required='' value=$fecha type='date'name='fecha' placeholder='Ingresa la fecha' id='fecha'>
        </div>
        <button class='btn-danger' type='submit'>Enviar</button>
        </form></div>");
        

        
        
            
    }
    else{header("Location: login.html");}
}


?>