<?php
require("db_config.php");
session_start();
//Este php permite al artista borrar una canción que prefiera.
if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){

        $nombre_cancion=$_POST["nombre_cancion"];
        echo($nombre_cancion);
        $sql_statement="select * from (select id_cancion,email,id_artista from artista_compuso_cancion inner join personas on id = id_artista) as artistaCancion inner join canciones on id_cancion = id WHERE email = $1 and id_cancion=$2";
        $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"],$nombre_cancion));
        $row = pg_fetch_row($result);
        $id_cancion=$row[0];
        $id_artista=$row[2];

        $sql_statement="DELETE FROM artista_compuso_cancion WHERE id_cancion = $1 and id_artista = $2";
        $result = pg_query_params($dbconn, $sql_statement, array($id_cancion,$id_artista));

        $sql_statement="DELETE FROM album_tiene_canciones WHERE id_cancion = $1";
        $result = pg_query_params($dbconn, $sql_statement, array($id_cancion));


        $sql_statement="DELETE FROM canciones WHERE id = $1";
        $result = pg_query_params($dbconn, $sql_statement, array($id_cancion));



        header("Location: crud_canciones.php");

        
    }
    else{header("Location: login.html");}
}

?>