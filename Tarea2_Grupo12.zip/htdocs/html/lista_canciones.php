<?php
require("db_config.php");
session_start();
include '../include/navbar.php';
//Permite ver al usuario las canciones que han sido creadas por los artistas.
if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona!=null){

        $consulta= "SELECT name_cancion,name_album, nombre_artistico,id_cancion FROM(SELECT id_artista,name_cancion,nombre AS name_album,artista_compuso_cancion.id_cancion FROM(SELECT * FROM (SELECT nombre AS name_cancion,id_cancion,id_album FROM canciones
        INNER JOIN album_tiene_canciones
        ON canciones.id = album_tiene_canciones.id_cancion) AS union1
        INNER JOIN album
        ON album.id=union1.id_album)AS union2
		INNER JOIN artista_compuso_cancion
		ON artista_compuso_cancion.id_cancion=union2.id_cancion) AS union3
		INNER JOIN personas
		ON personas.id=union3.id_artista";;

        $result=pg_query($dbconn,$consulta);
//inicio tabla
        //generar filas de table
        echo(' <table class="table table-dark table-striped">
        <thead>
    <tr>
      <th scope="col">Nombre Cancion</th>
      <th scope="col">Album</th>
      <th scope="col">Artista</th>
      <th scope="col">Conocer</th>
    </tr>
        </thead>
        <tbody>
        ');
        while ($row = pg_fetch_row($result)) {
	        //lista de canciones 
            echo "<tr>
            <td>$row[0]</td>
            <td>$row[1]</td>
            <td>$row[2]</td>
           <td>
           <form action='informacion_cancion.php' method='post'>
              <input type='hidden' name='id_cancion' value=$row[3]>
              <input type='submit' value='Ir a conocer'>
              </form>
            </td>
                 </tr>";
         }  
         echo("</tbody></table>");
//cierro la table      
    }

}   
?>