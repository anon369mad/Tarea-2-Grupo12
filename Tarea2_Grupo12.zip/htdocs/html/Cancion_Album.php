<?php

require("db_config.php");
session_start();

include '../include/navbar.php';

$nombre = $_POST["nombre"];
$letra = $_POST["letra"];
$fecha = $_POST["fecha"];
$IDalbum = $_POST["album"];

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

        
    if($Tipo_persona==null){
if (isset($_POST["Enviar datos"])) $ID=$_POST["Enviar datos"];




$sql_statement="SELECT * from (select id_album,email from artista_tiene_album inner join personas on id = id_artista) as artistaCancion inner join album on id_album = id WHERE email = $1";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    echo("<form action='Cancion_Album.php' method='post' target='_blank'>
    <p>

    Elegir Album:<br>");
    while ($row = pg_fetch_row($result)) {

        echo("<label><input required='' type='radio' name='id' value=''$row[0]'> NOMBRE ALBUM: $row[3]</label><br>");            
}
    echo("<p><input type='submit' value='Enviar datos'></p></form>");
    }
    else{header("location: ../index.php");}
}


?>