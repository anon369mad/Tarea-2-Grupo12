<?php

include '../include/navbar.php';

require("db_config.php");
session_start();

$boton="";
if(isset($_POST["boton"])) $boton=$_POST["boton"];

if($boton){
    $sql_statement="SELECT * from (select id_album,email from artista_tiene_album inner join personas on id = id_artista) as artistaCancion inner join album on id_album = id WHERE email = $1";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    while ($row = pg_fetch_row($result)) {

        echo ("<input type='radio' name='id' value='$row[0]'>");

        echo ("<b>ID ALBUM: $row[0]</b> <p> NOMBRE ALBUM: $row[3]   FECHA LANZAMIENTO: $row[5]</p>");
        echo "<br />\n";            
}

}
?>