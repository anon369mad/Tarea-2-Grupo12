<?php
//Este php. permite al usuario o artista cerrar su sesión.
session_start();
session_destroy();
header("Location: ../index.php");
?>
