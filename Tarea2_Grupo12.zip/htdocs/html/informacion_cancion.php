<?php
require("db_config.php");
session_start();

include '../include/navbar.php';

$id_cancion=$_POST['id_cancion'];
if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona!=null){
      echo"<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>";

      echo($id_cancion);
        $consulta="SELECT nombre_cancion, nombre_artistico,fecha_composicion,letra from personas inner join (select id as id_cancion,nombre AS nombre_cancion,letra,fecha_composicion,id_artista from canciones inner join artista_compuso_cancion on id=id_cancion) as consulta1 on id_artista = personas.id where id_cancion=$1";
        $result = pg_query_params($dbconn, $consulta, array($id_cancion));
        $row = pg_fetch_row($result);
        $letra= $row[3];
        echo("<h1>$row[0]</h1><h3>De $row[1] estrenado en $row[2]</h3> <h4>La puedes encontrar en los albumes:</h4>");

        $sql_statement="SELECT nombre from album inner join album_tiene_canciones on id=id_album where id_cancion=$1";
        $result = pg_query_params($dbconn, $sql_statement, array($id_cancion));

        while ($row = pg_fetch_row($result)) {
            $IDalbum= $row[0];
            echo("<p>$IDalbum</p>");
        }
        echo("</div>");

    }
    else{
      header("Location: lista_canciones.php");
    }
  } 

?>