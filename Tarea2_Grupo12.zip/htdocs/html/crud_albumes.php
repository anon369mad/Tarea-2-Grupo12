<?php
require("db_config.php");
session_start();
//Permite ver al artista todos los albumes que han sido creados.
include '../include/navbar.php';

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

        
    if($Tipo_persona==null){
        echo"<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>
        <h1>Tus Albumes</h1>";
        $sql_statement="SELECT * from (select id_album,email from artista_tiene_album inner join personas on id = id_artista) as artistaCancion inner join album on id_album = id WHERE email = $1";
        $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
        echo('<table class="table table-dark">
        <thead>
        <tr>
          <th scope="col">Id Álbum</th>
          <th scope="col">Nombre</th>
          <th scope="col">Edición</th>
          <th scope="col">Eliminación</th>
        </tr>
      </thead>
      <tbody>');
        while ($row = pg_fetch_row($result)) {
            echo ("<tr>
            <td>$row[0]</td>
            <td>$row[3]</td>
            <td> <form action='modificar_Album.php' method='post'> <input type='hidden' name='nombre_cancion' value=$row[0]> <input type='submit' value='Modificar'></form></td>
            <td> <form action='BorrarAlbum.php' method='post'> <input type='hidden' name='nombre_cancion' value=$row[0]> <input type='submit' value='Borrar'></form></td></tr>");            
    }
    echo "</tbody></table><form action='AgregarAlbum.html'>
    <button class='btn-danger' type='submit'>Agregar Album
</form></div>";}
    else{header("Location: login.html");}
}

?>