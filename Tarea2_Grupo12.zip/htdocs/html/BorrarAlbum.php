<?php
require("db_config.php");
session_start();
//Este php permite al artista poder borrar un album de su perfil
include '../include/navbar.php';

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){
        $IDalbum=$_POST["nombre_cancion"];

        $sql_statement="SELECT * from album_tiene_canciones where id_album=$1";
        $result = pg_query_params($dbconn, $sql_statement, array($IDalbum));

        $contadorCanciones=0;
        while ($row = pg_fetch_row($result)) {
            $contadorCanciones=$contadorCanciones+1;
            
        }

        if($contadorCanciones==0){
            $sql_statement="DELETE FROM artista_tiene_album WHERE id_album = $1";
        $result = pg_query_params($dbconn, $sql_statement, array($IDalbum));

        $sql_statement="DELETE FROM album_tiene_canciones WHERE id_album = $1";
        $result = pg_query_params($dbconn, $sql_statement, array($IDalbum));

        $sql_statement="DELETE FROM album WHERE id = $1";
        $result = pg_query_params($dbconn, $sql_statement, array($IDalbum));


        header("Location: crud_albumes.php");
            
        }

        else{
            echo"<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>";
            echo'<div class="alert alert-danger"><strong>Error:</strong> NO PODEMOS BORRAR TU ALBUM PORQUE CONTIENE CANCIONES.</div>';
            echo("<h4>Para borrar el album debes borrar las canciones que contiene el album o mover las canciones a otro album</h4>");
            $sql_statement="select * from album_tiene_canciones inner join canciones on id = id_cancion where id_album=$1";
            $result = pg_query_params($dbconn, $sql_statement, array($IDalbum));
            echo("<h4>Estas son las canciones que estan en el album:</h4>");
            while ($row = pg_fetch_row($result)) {
                echo "<b>ID:</b> $row[2] <b>Nombre Canción</b>: $row[3]";
                echo "<br />\n";
                
            
        }
        echo("<form action='crud_albumes.php'>
            <button class='btn-danger' type='submit'>REGRESAR</button>
        </form>");
        echo("<form action='crud_canciones.php'>
            <button class='btn-danger' type='submit'>Modificar Canciones</button>
        </form></div>");
            
        }




        
    }
    else{header("Location: login.html");}
}

?>