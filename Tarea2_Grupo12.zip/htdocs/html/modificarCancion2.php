<?php
require("db_config.php");
session_start();

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){
        $nombre = $_POST["nombre"];
        $letra = $_POST["letra"];
        $fecha = $_POST["fecha"];
        $id = $_POST["Id_cancion"];


        if(isset($_POST["id"])){
            $IDSalbum = $_POST["id"];
            $consulta = "UPDATE canciones SET nombre = $1, letra = $2, fecha_composicion = $3 WHERE id = $4";
            $resultado = pg_query_params($dbconn, $consulta, array($nombre,$letra,$fecha,$id));

            $consulta = "DELETE FROM album_tiene_canciones WHERE id_cancion = $1";
            $resultado = pg_query_params($dbconn, $consulta, array($id));

            foreach($IDSalbum as $IDalbum){
                $sql_statement = "INSERT INTO album_tiene_canciones VALUES ($1,$2)";
                $result = pg_query_params($dbconn, $sql_statement, array($IDalbum,$id));
        
                
            }
            header("Location: crud_canciones.php");
        }
        else{echo"Debes colocar al menos un album";}
       

    }
    else{header("Location: login.html");}
}


?>