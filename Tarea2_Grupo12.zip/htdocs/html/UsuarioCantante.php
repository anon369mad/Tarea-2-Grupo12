<?php
include '../include/navbar.php';
//Transforma un usuario a un cantante.
require("db_config.php");
require("hash_password.php");
session_start();
echo('<div class="position-absolute top-50 start-50 translate-middle  bg-success p-2 text-white bg-opacity-25">');
echo("<p>Haz encontrado la zona secreta para volverte cantante</p>");
echo("<p>Una vez hecho no hay vuelta atras</p>");
echo("<form action='' method='POST'>
<div>
    <label for='nombre_cantante'>Coloca tu nickname de cantante</label>
    <input required='' type='text'name='nombre_cantante' placeholder='Ingresa el nombre' id='nombre_cantante'>
    <label for='nombre_cantante'>Contraseña para confirmar</label>
    <input required='' type = 'password' placeholder='Ingrese su contraseña' name='password'>
</div> <div> <button name='Cumplido' type='submit'>Enviar</button>
    </form>");

$nombre_cantante=$_POST["nombre_cantante"];
$password = $_POST["password"];
$email = $_SESSION["email"];


$sql_statement = "SELECT password FROM personas WHERE email = $1;";
$result = pg_query_params($dbconn, $sql_statement, array($email));
$row = pg_fetch_row($result);
$password_hashed = $row[0];

if (password_verify($password, $password_hashed)) {
    $sql_statement="UPDATE personas SET suscripcion_activa=null, nombre_artistico=$1, verificado=false WHERE email=$2";
    $result = pg_query_params($dbconn, $sql_statement, array($nombre_cantante,$email));

    header("location: ../index.php");
   }

echo("</div>");


?>
    

