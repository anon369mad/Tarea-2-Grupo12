<?php
include("../include/navbar.php");
require("db_config.php");
session_start();
echo('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
rel="stylesheet" 
integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
crossorigin="anonymous">');


if (!isset($_SESSION["email"])) {
    header("Location: login.html");
   }
else{
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));

    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];
    if($Tipo_persona==null){echo("<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>
      <h1>CANTANTE</h1> <form action='crud_canciones.php'>
        <button class='btn-danger' type='submit'>Modificar canciones</button>
    </form>
    <form action='crud_albumes.php'>
        <button class='btn-danger' type='submit'>Modificar Album</button>
    </form>
    </div>"
  );}
    else {
        echo('<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand btn btn-outline-success  text-success" href="informacion_usuario.php">Información Perfil</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="lista_canciones.php">Lista de Canciones</a>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled">INNOVA</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      ');

    }
}  
  


?>