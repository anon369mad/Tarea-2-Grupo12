<?php
require("db_config.php");
session_start();


if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){
        $nombre = $_POST["nombre"];
        $imagen = $_POST["imagen"];
        $fecha = $_POST["fecha"];
        $id = $_POST["Id_cancion"];

        $consulta = "UPDATE album SET nombre = $1, imagen = $2, fecha_lanzamiento = $3 WHERE id = $4";
        $resultado = pg_query_params($dbconn, $consulta, array($nombre,$imagen,$fecha,$id));
        
        header("Location: crud_albumes.php");
       


    }
    else{header("Location: login.html");}
}


?>