<?php

    include '../include/navbar.php';
    require("db_config.php");
    session_start();

    if (!isset($_SESSION["email"])) {
        header("Location: login.html");   
       }
    else{
        //VERIFICAR USUARIO
        $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
        $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
        $row = pg_fetch_row($result);
        $Tipo_persona = $row[0];
    
            
        if($Tipo_persona==null){

    $sql_statement="SELECT id from personas where email=$1";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Idpersona=$row[0];


    $sql_statement="SELECT * from artista_tiene_album where id_artista=$1";
    $result = pg_query_params($dbconn, $sql_statement, array($Idpersona));
    $contadorAlbum=0;
    while ($row = pg_fetch_row($result)) {
        $contadorAlbum=$contadorAlbum+1;            
    }
    if ($contadorAlbum==0){
        echo"<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>";
        echo "'<div class='alert alert-danger'><strong>Error:</strong> no tienes  ningun album, crea uno aqui.</div>";
        echo("<form action='AgregarAlbum.php'>
            <button class='btn-danger' type='submit'>Agregar Album</button>
        </form></div>");
    }

    else{



    echo("<!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <title>Administración de Canciones</title>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3' crossorigin='anonymous'>
        <script src='main.js'></script>
    </head>
    <body>
    <div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>
        <h1>AGREGA TU CANCION</h1>
        <form action='AgregarCancion2.php' method='POST'>
            <div>
                <label for='nombre'>Nombre</label>
                <input required='' type='text'name='nombre' placeholder='Ingresa tu nombre' id='nombre'>
            </div>
        
            <div>
                <label for='letra'>Letra</label>
                <input type='text'name='letra' placeholder='Ingresa la Letra' id='letra'>
            </div>
        
            <div>
                <label for='Fecha'>Fecha composicion</label>
                <input required='' type='date' name='fecha' placeholder='Ingresa la fecha' id='fecha'>
            </div>
        
            <div> <p>

            Elegir Album:<br>");
    
$sql_statement="SELECT * from (select id_album,email from artista_tiene_album inner join personas on id = id_artista) as artistaCancion inner join album on id_album = id WHERE email = $1";
$result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
            while ($row = pg_fetch_row($result)) {
                echo(" <label><input type='checkbox' name='id[]' value=$row[0]> <b>ID: $row[0] NOMBRE:</b> $row[3]</label><br>");
            }
            
    
    
    
    echo("<div> <button type='submit'>Enviar</button>
    </form> </div></body>
    </html>");
        }

    }

    else{header("location: ../index.php");}

}

  

?>


