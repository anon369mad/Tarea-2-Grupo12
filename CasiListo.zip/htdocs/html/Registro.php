<?php

require("db_config.php");
require("hash_password.php");

include '../include/navbar.php';

$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
if ($apellido==""){$apellido=null;}
$email = $_POST["email"];
$contraseña = $_POST["contraseña"];
$suscrip='false';

$password_hashed = hash_password($contraseña);

$sql_statement="SELECT email from personas where email=$1";
$result = pg_query_params($dbconn, $sql_statement, array($email));
$row = pg_fetch_row($result);
if($row[0]!=$email){
    $sql_statement = "INSERT INTO personas(nombre, apellido, email, password, suscripcion_activa) VALUES ($1,$2,$3,$4,$5);";
$result = pg_query_params($dbconn, $sql_statement, array($nombre,$apellido,$email,$password_hashed,$suscrip));
if ($result) {
 echo("<h3 class='p-3 mb-2 bg-success text-white'>¡Guardado con éxito!</h3>");
} else {
 echo("¡Error!");

}
}
else{
    echo '<div class="alert alert-danger"><strong>Error:</strong> Este correo ya existe.</div>';
}




?>
