<?php

require("db_config.php");
require("hash_password.php");

$email = $_POST["email"];
$password = $_POST["password"];



$sql_statement = "SELECT password FROM personas WHERE email = $1;";
$result = pg_query_params($dbconn, $sql_statement, array($email));


if (!$result) {
    exit();
   }
   header("location: login.html"); 

$row = pg_fetch_row($result);
$password_hashed = $row[0];

if (password_verify($password, $password_hashed)) {
    session_start();
    $_SESSION["email"] = $email;
    header("location: ../index.php");
   }

?>