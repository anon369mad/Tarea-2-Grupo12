<?php 
include '../include/navbar.php';
require("db_config.php"); 
session_start();

if (!isset($_SESSION["email"])) {
  header("Location: login.html");   
 }
else{
  

$email_global=$_SESSION["email"];
$consulta="SELECT * FROM personas WHERE email=$1";
$result=pg_query_params($dbconn,$consulta,array($_SESSION["email"]));
$row=pg_fetch_row($result);

if($row[5]!=null){
    $tipo='No Artista, Usuario Sin suscripción';
    if($row[5]==true){
        $tipo='No Artista, Usuario Con suscripción';
    }
}
else{
    $tipo='Artista: '.$row[6] ;
}

echo '<center><div class="card mb-3 position-absolute top-50 start-50 translate-middle" style="max-width: 540px; ">
<div class="row g-0">
  <div class="col-md-4">
    <img src="../img/user.png" class="img-fluid rounded-start w-100 h-70 mt-3 mb-2">
  </div>
  <div class="col-md-8">
    <div class="card-body ">
      <h5 class="display-2">'.$row[1].'</br><p class="h6">'.$tipo.'</p></h5>
      <div class="mb-2 row ">
      <label for="apellido" class="col-sm-4 col-form-label  bg-secondary opacity-75 text-light">Apellido</label>
      <div class="col-sm-8">
        <input type="text" readonly class="form-control-plaintext border border-secondary"" id="apellido" value=" '.$row[2].'">
      </div>
    </div>
    <div class="mb-3 row ">
      <label for="staticEmail" class="col-sm-4 col-form-label bg-secondary opacity-75 text-light ">Email</label>
      <div class="col-sm-8">
      <input type="text" readonly class="form-control-plaintext border border-secondary"" id="staticEmail" value=" '.$row[3].'">
      </div>
    </div>

      <p class="card-text"><small class="text-muted">User innova musica</small></p>
    </div>
  </div>
</div>
</div></center>';
}



?>