<?php

require("db_config.php");
session_start();

include '../include/navbar.php';



$nombre = $_POST["nombre"];
$imagen = $_POST["imagen"];
$fecha = $_POST["fecha"];

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

        
    if($Tipo_persona==null){

$sql_statement = "INSERT INTO album(nombre, imagen, fecha_lanzamiento) VALUES ($1,$2,$3);";
$result = pg_query_params($dbconn, $sql_statement, array($nombre,$imagen,$fecha));


$sql_statement = "SELECT id FROM personas WHERE email = $1;"; 
$result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
$row = pg_fetch_row($result);
$IdCantante = $row[0];


$sql_statement = $sql_statement = "SELECT id FROM album WHERE nombre = $1 and imagen = $2 and fecha_lanzamiento =$3"; 
$result = pg_query_params($dbconn, $sql_statement, array($nombre,$imagen,$fecha));
$row = pg_fetch_row($result);
$Idalbum = $row[0];

$sql_statement = "INSERT INTO artista_tiene_album(id_artista, id_album ) VALUES ($1,$2);";
$result = pg_query_params($dbconn, $sql_statement, array($IdCantante,$Idalbum));


header("location: crud_albumes.php");
    }
else{header("Location: ../index.php");}
}



?>