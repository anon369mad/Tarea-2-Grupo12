<?php
require("db_config.php");
session_start();
include '../include/navbar.php';

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){
        $nombre_cancion=$_POST["nombre_cancion"];
        $sql_statement="select * from (select id_cancion,email from artista_compuso_cancion inner join personas on id = id_artista) as artistaCancion inner join canciones on id_cancion = id WHERE email = $1 and id_cancion=$2";
        $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"],$nombre_cancion));

        $row = pg_fetch_row($result);
        $id=$row[0];
        $nombre = $row[3];
        $letra = $row[4];
        $fecha = $row[5];



        echo("<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>");
        echo("<h3>INGRESE LOS DATOS NUEVAMENTE EN EL FORMULARIO</h3>");
        echo("<p>NOMBRE:".$nombre."</p>");
        echo("<p>LETRA:".$letra."</p>");
        echo("<p>FECHA:".$fecha."</p>");

        $sql_statement="SELECT id_album from album_tiene_canciones where id_cancion=$1";
        $result = pg_query_params($dbconn, $sql_statement, array($nombre_cancion));
        while ($row = pg_fetch_row($result)) {
            $IDalbum= $row[0];
            echo("<p>ID ALBUM:".$IDalbum."</p>");
        }

        echo("<form action='modificarCancion2.php' method='POST'>
        <div>
            <label for='nombre'>Nombre</label>

            <input  value=$id type='hidden'name='Id_cancion' placeholder='Ingresa tu nombre' id='Id_cancion'>

            <input required=''  type='text'name='nombre' placeholder='Ingresa tu nombre' id='nombre'>
        </div>
    
        <div>
            <label for='letra'>Letra</label>
            <input required='' type='text' name='letra' placeholder='Ingresa la Letra' id='letra'>
        </div>
    
        <div>
            <label for='Fecha'>Fecha composicion</label>
            <input required='' value=$fecha type='date'name='fecha' placeholder='Ingresa la fecha' id='fecha'>
            </div>
        
            <div> <p>

            Elegir Album:<br>");
    
$sql_statement="SELECT * from (select id_album,email from artista_tiene_album inner join personas on id = id_artista) as artistaCancion inner join album on id_album = id WHERE email = $1";
$result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
            while ($row = pg_fetch_row($result)) {
                echo(" <label><input type='checkbox' name='id[]' value=$row[0]> <b>ID: $row[0] NOMBRE:</b> $row[3]</label><br>");
            }
            
    
    
    
    echo("<div> <button type='submit'>Enviar</button>
    </form> </div>  </body>
    </html>");
        

        
        
            
    }
    else{header("Location: login.html");}
}


?>