<?php

require("db_config.php");
session_start();

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

        
    if($Tipo_persona==null){

$nombre = $_POST["nombre"];
$letra = $_POST["letra"];
$fecha = $_POST["fecha"];


if(isset($_POST["id"])){
    $IDSalbum = $_POST["id"];
    
    $sql_statement = "INSERT INTO canciones(nombre, letra, fecha_composicion) VALUES ($1,$2,$3);";
    $result = pg_query_params($dbconn, $sql_statement, array($nombre,$letra,$fecha));
    
    
    
    $sql_statement  = "SELECT id FROM personas WHERE email = $1;"; 
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $IdCantante = $row[0];
    
    $sql_statement = "SELECT id FROM canciones WHERE nombre = $1 and letra = $2 and fecha_composicion =$3"; 
    $result = pg_query_params($dbconn, $sql_statement, array($nombre,$letra,$fecha));
    $row = pg_fetch_row($result);
    $IdCancion = $row[0];
    
    $sql_statement = "INSERT INTO artista_compuso_cancion(id_artista, id_cancion ) VALUES ($1,$2);";
    $result = pg_query_params($dbconn, $sql_statement, array($IdCantante,$IdCancion));
    

    foreach($IDSalbum as $IDalbum){
        $sql_statement = "INSERT INTO album_tiene_canciones VALUES ($1,$2)";
        $result = pg_query_params($dbconn, $sql_statement, array($IDalbum,$IdCancion));

        
    }

    
    header("location: crud_canciones.php");
    


}
else{echo "Debes colocar al menos un album";}
    }
    else{
        header("location: ../index.php");
    }
}




?>