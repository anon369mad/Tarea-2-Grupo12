<?php
require("db_config.php");
session_start();

include '../include/navbar.php';

if (!isset($_SESSION["email"])) {
    header("Location: login.html");   
   }
else{
    //VERIFICAR USUARIO
    $sql_statement = "SELECT suscripcion_activa FROM personas WHERE email = $1;";
    $result = pg_query_params($dbconn, $sql_statement, array($_SESSION["email"]));
    $row = pg_fetch_row($result);
    $Tipo_persona = $row[0];

    if($Tipo_persona==null){
        $consulta="SELECT * from (select id_cancion,email from artista_compuso_cancion inner join personas on id = id_artista) as artistaCancion inner join canciones on id_cancion = id WHERE email = $1;";
        $result = pg_query_params($dbconn, $consulta, array($_SESSION["email"]));
        echo"<div class='position-absolute top-50 start-50 translate-middle  btn bg-secondary bg-gradient'>";
        
        while ($row = pg_fetch_row($result)) {
	        echo "Nombre Canción: $row[3]  Letra: $row[4]<form action='modificar_cancion.php' method='post'> <input type='hidden' name='nombre_cancion' value=$row[0]> <input type='submit' value='Modificar'></form>
            <form action='BorrarCancion.php' method='post'> <input type='hidden' name='nombre_cancion' value=$row[0]> <input type='submit' value='Borrar'></form>";
	        echo "<br />\n";            
    }
    echo
    "<form action='AgregarCancion.php'>
        <button class='btn-danger' type='submit'>Agregar Cancion
    </form>
    </div>";}
    else{header("Location: login.html");}
}

?>