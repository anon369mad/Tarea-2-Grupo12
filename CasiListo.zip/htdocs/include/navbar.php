<?php
session_start();

include 'db_config.php';
include 'header.html';


if (!isset($_SESSION["email"])) {
    echo("

    <nav class='nav bg-gray-black text-dark bg-dark text-white'>
        <div class='nav p-3 ms-4'>
            <a class='navbar-brand btn btn-secondary mt-3' href='../index.php'>Inicio</a>
            <a class='navbar-brand btn btn-secondary mt-3' href='../html/who.html'>Quienes Somos</a>
            <a class='navbar-brand btn btn-secondary mt-3' href='#'>Chiste</a>
            <a class='navbar-brand position-absolute top-0 end-0 btn btn-secondary mt-3' href='../html/login.html'>Sign in / Sign Up</a>

        </div>
    </nav>");   
   }
else{

echo("

    <nav class='nav bg-gray-black text-dark bg-dark text-white'>
        <div class='nav p-3 ms-4'>
            <a class='navbar-brand btn btn-secondary mt-3' href='../index.php'>Inicio</a>
            <a class='navbar-brand btn btn-secondary mt-3' href='../html/who.html'>Quienes Somos</a>
            <a class='navbar-brand btn btn-secondary mt-3' href='#'>Chiste</a>
            <a class='navbar-brand btn btn-secondary mt-3' href='../html/informacion_usuario.php'>Datos</a>
            <a class='navbar-brand position-absolute top-0 end-0 btn btn-secondary mt-3' href='../html/salir.php'>Salir</a>

        </div>
    </nav>");
}
?>
    

    
    